// Variáveis globais para controle das cenas e posições dos ratos
let currentScene = 0; // 0: Campo, 1: Cidade, 2: Rato do Campo na Cidade, 3: Rato da Cidade no Campo, 4: Conexão Final
let fieldMouseX, fieldMouseY; // Posição do rato do campo
let cityMouseX, cityMouseY;    // Posição do rato da cidade

let lastSceneChangeTime = 0;
const SCENE_DURATION = 8000; // Duração de cada cena em milissegundos (8 segundos)
const TRANSITION_DURATION = 2000; // Duração da transição em milissegundos (2 segundos)

let globalParticleSystem; // Declara o sistema de partículas para a cena de conexão

// --- CLASSES (definições de objetos) ---
// É uma boa prática definir classes antes de serem usadas no setup()

/**
 * Representa uma única partícula no sistema.
 */
class Particle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.vx = random(-2, 2); // Velocidade no eixo X
        this.vy = random(-2, 2); // Velocidade no eixo Y
        this.alpha = 255; // Opacidade inicial
        // Cores vibrantes aleatórias com opacidade inicial
        this.color = color(random(150, 255), random(150, 255), random(150, 255), this.alpha);
        this.size = random(4, 10); // Tamanho da partícula
    }

    update() {
        this.x += this.vx; // Atualiza a posição X
        this.y += this.vy; // Atualiza a posição Y
        this.alpha -= 3; // Diminui a opacidade (desaparece mais rápido)
    }

    display() {
        noStroke(); // Sem contorno
        this.color.setAlpha(this.alpha); // Define a opacidade atual da cor
        fill(this.color); // Preenche com a cor da partícula
        ellipse(this.x, this.y, this.size, this.size); // Desenha a partícula como um círculo
    }
}

/**
 * Gerencia uma coleção de partículas.
 */
class ParticleSystem {
    constructor() {
        this.particles = []; // Array para armazenar as partículas
        // Inicializa com algumas partículas espalhadas
        for (let i = 0; i < 100; i++) {
            this.particles.push(new Particle(random(width), random(height)));
        }
    }

    addParticles(x, y) {
        // Adiciona algumas partículas a cada frame para um efeito contínuo
        for (let i = 0; i < 5; i++) {
            this.particles.push(new Particle(x, y));
        }
    }

    run() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            let p = this.particles[i];
            p.update(); // Atualiza a partícula
            p.display(); // Exibe a partícula

            // Remove a partícula se ela for muito transparente
            if (p.alpha < 0) {
                this.particles.splice(i, 1);
            }
        }
    }
}


// --- FUNÇÕES ESSENCIAIS DO P5.JS ---

/**
 * Inicializa o canvas p5.js e configura o estado inicial da animação.
 * É chamado uma vez ao carregar o programa.
 */
function setup() {
    createCanvas(800, 600); // Cria um canvas de 800x600 pixels
    initializeSceneElements(); // Configura as posições iniciais dos elementos
    globalParticleSystem = new ParticleSystem(); // Inicializa o sistema de partículas
    lastSceneChangeTime = millis(); // Registra o tempo de início para controle das cenas
}

/**
 * Loop principal de desenho, chamado continuamente pelo p5.js.
 * Gerencia as transições de cena automáticas e chama a função de desenho da cena apropriada.
 */
function draw() {
    let currentTime = millis(); // Tempo atual em milissegundos
    let timeInCurrentScene = currentTime - lastSceneChangeTime; // Tempo decorrido na cena atual

    // Lógica de transição automática de cena
    if (timeInCurrentScene > SCENE_DURATION + TRANSITION_DURATION) {
        currentScene = (currentScene + 1) % 5; // Alterna entre as cenas (0, 1, 2, 3, 4)
        initializeSceneElements(); // Reinicia posições para a nova cena
        lastSceneChangeTime = currentTime; // Atualiza o tempo da última mudança de cena
    }

    // Desenha a cena atual com base na variável 'currentScene'
    switch (currentScene) {
        case 0: // Cena Rural (Campo)
            drawRuralScene();
            // O rato do campo está parado nesta cena, sem animação de movimento ou patas
            drawMouse(fieldMouseX, fieldMouseY, color(180, 180, 180), 1, 0); // animationPhase 0 para patas paradas
            break;
        case 1: // Cena da Cidade
            drawCityScene();
            // O rato da cidade está parado nesta cena, sem animação de movimento ou patas
            drawMouse(cityMouseX, cityMouseY, color(100, 100, 100), -1, 0); // animationPhase 0 para patas paradas
            break;
        case 2: // Rato do Campo visita a Cidade
            drawCityScene(); // Fundo da cidade
            // Anima o rato do campo (cinza claro) movendo-se da esquerda para a direita na cidade
            let fieldMouseMoveProgress = (timeInCurrentScene - TRANSITION_DURATION) / (SCENE_DURATION - TRANSITION_DURATION);
            let currentFieldMouseXCity = lerp(width * 0.1, width * 0.9, fieldMouseMoveProgress);
            // Ajusta a posição Y para que o rato do campo ande na calçada da cidade
            currentFieldMouseYCity = (height * 0.8) - 35; // Ajustado para a linha cinza claro da calçada
            // A animação das patas será gerenciada dentro de animateMouseWalking
            animateMouseWalking(currentFieldMouseXCity, currentFieldMouseYCity, color(180, 180, 180), 1);
            break;
        case 3: // Rato da Cidade visita o Campo
            drawRuralScene(); // Fundo rural
            // Anima o rato da cidade (cinza escuro) movendo-se da direita para a esquerda no caminho de terra
            let cityMouseMoveProgress = (timeInCurrentScene - TRANSITION_DURATION) / (SCENE_DURATION - TRANSITION_DURATION);
            let currentCityMouseXRural = lerp(width * 0.9, width * 0.1, cityMouseMoveProgress);
            // Ajusta a posição Y para que o rato da cidade também ande no caminho de terra na cena rural
            let currentCityMouseYRural = height * 0.86;
            // A animação das patas será gerenciada dentro de animateMouseWalking
            animateMouseWalking(currentCityMouseXRural, currentCityMouseYRural, color(100, 100, 100), -1);
            break;
        case 4: // Cena de Conexão Final
            drawConexaoScene();
            // Adiciona partículas onde o mouse está (para interatividade)
            globalParticleSystem.addParticles(mouseX, mouseY);
            globalParticleSystem.run(); // Executa o sistema de partículas
            drawConfetti(mouseX, mouseY, 20); // Confetes reagem ao mouse
            break;
    }

    // Desenha a sobreposição de transição (efeito fade in/out)
    if (timeInCurrentScene < TRANSITION_DURATION) {
        let alpha = map(timeInCurrentScene, 0, TRANSITION_DURATION, 255, 0); // Fade out
        fill(0, alpha); // Preenche com preto e transparência decrescente
        rect(0, 0, width, height); // Desenha um retângulo sobre todo o canvas
    } else if (timeInCurrentScene > SCENE_DURATION) {
        let alpha = map(timeInCurrentScene, SCENE_DURATION, SCENE_DURATION + TRANSITION_DURATION, 0, 255); // Fade in
        fill(0, alpha); // Preenche com preto e transparência crescente
        rect(0, 0, width, height); // Desenha um retângulo sobre todo o canvas
    }
}


// --- FUNÇÕES DE INICIALIZAÇÃO E AUXILIARES ---

/**
 * Reinicia as posições dos elementos da cena para seus valores padrão.
 * Ajusta a posição Y dos ratos para que andem no caminho de terra.
 */
function initializeSceneElements() {
    // Ajustamos Y para compensar as patas e o movimento
    fieldMouseX = width * 0.2;
    fieldMouseY = height * 0.86; // Ajustado para o caminho de terra e para as patas aparecerem
    // Ajuste para posicionar os ratos da cidade no topo da calçada
    // A calçada começa em height * 0.8 - 20
    // Como as patas são desenhadas 15px abaixo do centro do rato,
    // o centro do rato deve estar em (height * 0.8 - 20) - 15 = height * 0.8 - 35
    cityMouseX = width * 0.8;
    cityMouseY = (height * 0.8) - 35; // Ajustado para que as patas fiquem na linha cinza claro da calçada
}

// --- Funções de Desenho de Cenas ---

/**
 * Desenha a cena rural com um céu simples, chão plano, sol, nuvens, cerca e um trator parado.
 * O chão agora tem um caminho de terra para os ratos.
 */
function drawRuralScene() {
    // Céu simples
    background(173, 216, 230); // Céu azul claro

    // Sol
    fill(255, 223, 0); // Amarelo vibrante
    ellipse(width * 0.2, height * 0.2, 80, 80);

    // Nuvens
    drawCloud(width * 0.6, height * 0.15, 100);
    drawCloud(width * 0.8, height * 0.2, 80);

    // Chão verde plano
    noStroke(); // Remove o contorno
    fill(85, 107, 47); // Verde escuro (grama)
    rect(0, height * 0.7, width, height * 0.3); // Chão plano

    // Caminho de terra no chão
    fill(139, 90, 43); // Cor de terra
    beginShape();
    vertex(0, height * 0.8);
    curveVertex(width * 0.2, height * 0.78);
    curveVertex(width * 0.5, height * 0.82);
    curveVertex(width * 0.8, height * 0.79);
    vertex(width, height * 0.8);
    vertex(width, height);
    vertex(0, height);
    endShape(CLOSE);

    // Cerca (posicionada para estar sobre o chão plano)
    let fenceY = height * 0.75; // Posição vertical da cerca
    let fenceSegmentLength = 80; // Comprimento de um segmento da cerca
    // Loop para desenhar vários segmentos da cerca ao longo da largura do canvas
    for (let i = 0; i < width / fenceSegmentLength; i++) {
        drawFence(i * fenceSegmentLength, fenceY, fenceSegmentLength, 60);
    }

    // Trator fixo no fundo da cena
    let tractorX = width * 0.7; // Posição X fixa para o trator
    // Desenha o trator, reduzido para dar a impressão de estar no fundo
    drawTractor(tractorX, height * 0.68, 0.7);

    // Celeiro adicionado à cena rural
    // A posição Y é calculada para que a base do celeiro encoste no chão (height * 0.7)
    // Aumentamos o celeiro para um tamanho mais proeminente
    drawBarn(width * 0.2, height * 0.7, 200, 150); // Ajuste de largura para 200 e altura para 150

    // Macieiras (adicionadas aqui)
    // A posição Y é definida pela linha do chão (height * 0.7)
    drawAppleTree(width * 0.45, height * 0.7, 120, 100); // Macieira no meio
    drawAppleTree(width * 0.05, height * 0.7, 100, 90); // Macieira à esquerda, menor
    drawAppleTree(width * 0.85, height * 0.7, 130, 110); // Macieira à direita, maior

    // Blocos de feno (adicionados aqui)
    // As posições Y são ajustadas para que os blocos estejam encostados no chão (height * 0.7)
    drawHayBale(width * 0.1, height * 0.7);
    drawHayBale(width * 0.3, height * 0.7);
    drawHayBale(width * 0.6, height * 0.7);
}

/**
 * Desenha a cena da cidade com prédios, uma rua, carros, lua e estrelas.
 */
function drawCityScene() {
    background(40, 50, 70); // Céu noturno escuro

    // Lua
    noStroke(); // Garante que a lua não tenha contorno
    fill(200, 200, 180); // Cor da lua
    ellipse(width * 0.8, height * 0.15, 60, 60);

    // Estrelas
    drawStars(120);

    // Prédios
    noStroke(); // Remove o contorno
    drawBuilding(width * 0.1, height * 0.3, 80, height * 0.7, color(60, 60, 60));
    drawBuilding(width * 0.25, height * 0.4, 60, height * 0.6, color(70, 70, 70));
    drawBuilding(width * 0.4, height * 0.2, 90, height * 0.8, color(55, 55, 55));
    drawBuilding(width * 0.55, height * 0.5, 50, height * 0.5, color(65, 65, 65));
    drawBuilding(width * 0.7, height * 0.35, 70, height * 0.65, color(75, 75, 75));
    drawBuilding(width * 0.85, height * 0.45, 40, height * 0.55, color(60, 60, 60));

    // Calçada (Sidewalk)
    noStroke(); // Garante que a calçada não tenha contorno
    fill(180, 180, 180); // Cor para a calçada (cinza claro)
    rect(0, height * 0.8 - 20, width, 20); // Calçada de 20px de altura, acima do meio-fio

    // Meio fio (Curb)
    noStroke(); // Garante que o meio-fio não tenha contorno
    fill(100, 100, 100); // Cor para o meio fio (cinza um pouco mais claro que a rua)
    rect(0, height * 0.8, width, 5); // Meio fio de 5px de altura, no topo da rua

    // Rua principal (Road)
    noStroke(); // Garante que a rua não tenha contorno
    fill(80, 80, 80); // Cor da rua
    rect(0, height * 0.8 + 5, width, height * 0.2 - 5); // O restante da rua

    // Faixas brancas pontilhadas (agora com movimento)
    stroke(255); // Cor branca para as faixas
    strokeWeight(4); // Espessura das faixas
    let dashLength = 40; // Comprimento de cada traço
    let gapLength = 40;  // Espaçamento entre os traços
    let totalPatternLength = dashLength + gapLength;

    // Posição vertical da faixa (no meio da rua)
    let laneY = height * 0.8 + 5 + (height * 0.2 - 5) / 2;

    // Loop para desenhar as faixas ao longo da largura do canvas
    // O offset (frameCount * 3) cria o efeito de movimento das faixas
    for (let x = (frameCount * 3) % totalPatternLength - totalPatternLength; x < width; x += totalPatternLength) {
        line(x, laneY, x + dashLength, laneY);
    }
    noStroke(); // Desativa o contorno após desenhar as faixas para não afetar os carros e ratos.

    // Carros detalhados com movimento suave e luzes dinâmicas
    drawDetailedCar((frameCount * 1.5) % (width + 150) - 100, height * 0.85 + 5, color(255, 50, 50)); // Ajustado para ficar na rua
    drawDetailedCar((frameCount * 2.0 + width * 0.3) % (width + 150) - 100, height * 0.9 + 5, color(50, 50, 255)); // Ajustado para ficar na rua
    drawDetailedCar((frameCount * 2.5 + width * 0.6) % (width + 150) - 100, height * 0.88 + 5, color(50, 200, 50)); // Ajustado para ficar na rua
}

/**
 * Desenha a cena de conexão final com um gradiente de fundo, texto festivo,
 * ambos os ratinhos, uma fogueira e partículas/confetes interativos.
 */
function drawConexaoScene() {
    // Gradiente de fundo que une as cores do campo e da cidade
    for (let y = 0; y < height; y++) {
        let inter = map(y, 0, height, 0, 1);
        let c1 = color(173, 216, 230); // Cor do céu do campo
        let c2 = color(40, 50, 70); // Cor do céu noturno da cidade
        let mixedColor = lerpColor(c1, c2, inter); // Mistura as cores
        stroke(mixedColor); // Define a cor da linha
        line(0, y, width, y); // Desenha uma linha horizontal
    }

    // Chão (grama/rua) se misturando
    noStroke(); // Remove o contorno
    fill(lerpColor(color(85, 107, 47), color(80, 80, 80), 0.5)); // Mistura de verde e cinza
    rect(0, height * 0.6, width, height * 0.4); // Desenha o chão

    // Texto festivo
    fill(255); // Cor branca para o texto
    textSize(40); // Tamanho da fonte
    textAlign(CENTER, CENTER); // Alinhamento do texto
    text("Festejando a Conexão!", width / 2, height * 0.2);
    textSize(24);
    text("Campo e Cidade: Juntos!", width / 2, height * 0.3);

    // Ratinhos ajustados para ficarem de frente um para o outro
    // Rato do Campo (cinza claro, olhando para a direita)
    // Ajustando a Y para o rato ficar na mesma linha da fogueira
    animateMouseWalking(width * 0.4, height * 0.86, color(180, 180, 180), 1);
    // Rato da Cidade (cinza escuro, olhando para a esquerda)
    animateMouseWalking(width * 0.6, height * 0.86, color(100, 100, 100), -1);

    // Fogueira entre os ratos com brilho
    drawCampfire(width * 0.5, height * 0.85); // Desenha a fogueira
    drawCampfireGlow(width * 0.5, height * 0.85); // Adiciona o brilho da fogueira
}

// --- Funções Auxiliares de Desenho e Animação ---

/**
 * Desenha um personagem rato.
 * @param {number} x - Coordenada X do rato.
 * @param {number} y - Coordenada Y do rato.
 * @param {p5.Color} mouseColor - Cor do rato.
 * @param {number} direction - Direção para onde o rato está virado (1 para direita, -1 para esquerda).
 * @param {number} animationPhase - Fase da animação para as patas (0 a 1).
 */
function drawMouse(x, y, mouseColor, direction = 1, animationPhase = 0) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a posição do rato
    scale(direction, 1); // Espelha o rato horizontalmente se a direção for -1

    // Corpo
    fill(mouseColor); // Define a cor do corpo do rato
    noStroke(); // Garante que o corpo do rato não tenha contorno indesejado
    ellipse(0, 0, 40, 30); // Desenha o corpo

    // Orelhas
    fill(mouseColor); // Orelhas da mesma cor do corpo
    noStroke(); // Garante que as orelhas não tenham contorno indesejado
    ellipse(-15, -15, 15, 15); // Orelha esquerda
    ellipse(15, -15, 15, 15);  // Orelha direita

    // Focinho
    fill(60); // Cor do focinho
    noStroke(); // Garante que o focinho não tenha contorno indesejado
    ellipse(20, 0, 10, 8); // Desenha o focinho

    // Olhos
    fill(0); // Cor dos olhos (preto)
    noStroke(); // Garante que os olhos não tenham contorno indesejado
    ellipse(10, -5, 5, 5); // Desenha o olho

    // Patas
    fill(mouseColor); // Cor das patas (mesma do corpo)
    noStroke(); // Sem contorno para as patas
    // Pata dianteira (alterna posição Y para simular passo)
    let frontPawY = 15 + sin(animationPhase * TWO_PI) * 3;
    ellipse(10, frontPawY, 8, 5);

    // Pata traseira (alterna posição Y de forma oposta)
    let backPawY = 15 + sin((animationPhase + 0.5) * TWO_PI) * 3;
    ellipse(-10, backPawY, 8, 5);

    // Cauda (linha simples com movimento)
    stroke(mouseColor); // Cor da cauda (mesma do corpo)
    strokeWeight(2);    // Espessura da cauda
    // Calcula a posição final da cauda com base no frameCount para movimento
    let tailEndX = -20 - 20 + sin(frameCount * 0.2) * 5;
    let tailEndY = 10 + 10 + cos(frameCount * 0.2) * 3;
    line(-20, 10, tailEndX, tailEndY); // Desenha a cauda

    pop(); // Restaura o estado anterior da transformação
}

/**
 * Anima um personagem rato caminhando (apenas balanço horizontal e patas).
 * @param {number} x - Coordenada X do rato.
 * @param {number} y - Coordenada Y do rato.
 * @param {p5.Color} mouseColor - Cor do rato.
 * @param {number} direction - Direção para onde o rato está virado (1 para direita, -1 para esquerda).
 */
function animateMouseWalking(x, y, mouseColor, direction) {
    let walkSpeed = 0.1; // Velocidade da animação de andar
    let horizontalOffset = cos(frameCount * walkSpeed * 0.5) * 5; // Oscilação horizontal (balanço)

    let finalX = x;
    if (direction === 1) { // Rato olhando para a direita
        finalX = x + horizontalOffset;
    } else { // Rato olhando para a esquerda
        finalX = x - horizontalOffset;
    }

    // A fase de animação para as patas é baseada no frameCount
    let animationPhase = (frameCount * walkSpeed / (TWO_PI * 2)) % 1; // Normaliza entre 0 e 1

    // Passa a posição Y base sem offset vertical
    drawMouse(finalX, y, mouseColor, direction, animationPhase);
}

/**
 * Desenha a forma de uma nuvem.
 * @param {number} x - Coordenada X do centro da nuvem.
 * @param {number} y - Coordenada Y do centro da nuvem.
 * @param {number} size - Tamanho base da nuvem.
 */
function drawCloud(x, y, size) {
    noStroke(); // Remove o contorno
    fill(255, 255, 255, 200); // Branco com transparência
    ellipse(x, y, size * 1.2, size); // Elipse principal
    ellipse(x + size * 0.4, y - size * 0.2, size * 0.8, size * 0.8); // Elipse superior direita
    ellipse(x - size * 0.3, y - size * 0.1, size * 0.9, size * 0.9); // Elipse superior esquerda
}

/**
 * Desenha um prédio com janelas.
 * @param {number} startX - Coordenada X do canto superior esquerdo do prédio.
 * @param {number} startY - Coordenada Y do canto superior esquerdo do prédio.
 * @param {number} buildingWidth - Largura do prédio.
 * @param {number} buildingHeight - Altura do prédio.
 * @param {p5.Color} buildingColor - Cor do prédio.
 */
function drawBuilding(startX, startY, buildingWidth, buildingHeight, buildingColor) {
    fill(buildingColor); // Define a cor do prédio
    rect(startX, startY, buildingWidth, buildingHeight); // Desenha o corpo do prédio
    drawWindows(startX, startY, buildingWidth, buildingHeight); // Desenha as janelas do prédio
}

/**
 * Desenha janelas em um prédio.
 * @param {number} startX - Coordenada X do canto superior esquerdo do prédio.
 * @param {number} startY - Coordenada Y do canto superior esquerdo do prédio.
 * @param {number} buildingWidth - Largura do prédio.
 * @param {number} buildingHeight - Altura do prédio.
 */
function drawWindows(startX, startY, buildingWidth, buildingHeight) {
    let windowSize = 12; // Tamanho de uma janela
    let gap = 8;         // Espaçamento entre as janelas
    // Loop para desenhar as janelas em linhas e colunas
    for (let y = startY + gap; y < startY + buildingHeight - gap; y += windowSize + gap) {
        for (let x = startX + gap; x < startX + buildingWidth - gap; x += windowSize + gap) {
            // Luzes piscando aleatoriamente com mais controle
            let lightAlpha = random(50, 255); // Transparência variável para o efeito de piscar
            if (random(1) < 0.1) { // 10% de chance de a luz estar desligada
                lightAlpha = 0;
            }
            fill(255, 204, 0, lightAlpha); // Cor da luz da janela (amarelo com transparência)
            rect(x, y, windowSize, windowSize); // Desenha a janela
        }
    }
}

/**
 * Desenha um segmento de cerca de madeira.
 * @param {number} x - Coordenada X do segmento da cerca.
 * @param {number} y - Coordenada Y do segmento da cerca.
 * @param {number} segmentLength - Comprimento de um segmento da cerca.
 * @param {number} segmentHeight - Altura do segmento da cerca.
 */
function drawFence(x, y, segmentLength, segmentHeight) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a posição do segmento da cerca
    noStroke(); // Remove o contorno
    fill(139, 69, 19); // Cor de madeira

    // Postes verticais
    rect(0, 0, 10, segmentHeight); // Poste esquerdo
    rect(segmentLength - 10, 0, 10, segmentHeight); // Poste direito

    // Tábuas horizontais
    rect(0, segmentHeight * 0.3, segmentLength, 10); // Tábua superior
    rect(0, segmentHeight * 0.7, segmentLength, 10); // Tábua inferior
    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha um trator.
 * @param {number} x - Coordenada X do trator.
 * @param {number} y - Coordenada Y do trator.
 * @param {number} scaleFactor - Fator de escala para o trator (ex: 0.7 para menor).
 */
function drawTractor(x, y, scaleFactor = 1) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a posição do trator
    scale(scaleFactor); // Aplica a escala

    // Corpo principal
    fill(200, 0, 0); // Vermelho do trator
    noStroke(); // Garante que o corpo do trator não tenha contorno indesejado
    rect(0, 0, 80, 40); // Desenha o corpo

    // Cabine
    fill(150); // Vidro da cabine
    noStroke(); // Garante que a cabine não tenha contorno indesejado
    rect(50, -30, 30, 30); // Desenha a cabine
    fill(150); // Cor do vidro da cabine
    noStroke(); // Garante que o vidro não tenha contorno indesejado
    rect(55, -25, 20, 20); // Desenha o vidro

    // Rodas
    fill(50); // Cor das rodas
    noStroke(); // Garante que as rodas não tenham contorno indesejado
    ellipse(20, 40, 30, 30); // Roda dianteira
    ellipse(70, 40, 45, 45); // Roda traseira

    // Cano de escape
    fill(100); // Cor do cano
    noStroke(); // Garante que o cano de escape não tenha contorno indesejado
    rect(60, -50, 5, 20); // Desenha o cano

    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha um carro detalhado.
 * @param {number} x - Coordenada X do carro.
 * @param {number} y - Coordenada Y do carro.
 * @param {p5.Color} carColor - Cor do carro.
 */
function drawDetailedCar(x, y, carColor) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a posição do carro

    // Base do carro
    noStroke(); // Garante que o corpo do carro não tenha contorno indesejado
    fill(carColor); // Cor do carro
    rect(0, 0, 70, 30); // Desenha a base

    // Teto
    noStroke(); // Garante que o teto não tenha contorno indesejado
    rect(10, -20, 50, 20); // Desenha o teto

    // Janelas
    noStroke(); // Garante que as janelas não tenham contorno indesejado
    fill(150, 200, 255, 180); // Azul claro para janelas
    rect(15, -15, 15, 15); // Janela dianteira
    rect(40, -15, 15, 15); // Janela traseira

    // Rodas
    noStroke(); // Garante que as rodas não tenham contorno indesejado
    fill(50); // Cor das rodas
    ellipse(15, 30, 20, 20); // Roda dianteira
    ellipse(55, 30, 20, 20); // Roda traseira

    // Faróis (opcional, se for cena noturna)
    if (currentScene === 1 || currentScene === 2) { // Apenas na cena da cidade (incluindo quando o rato do campo visita)
        // Brilho dinâmico para os faróis
        let lightBrightness = map(sin(frameCount * 0.1 + x * 0.01), -1, 1, 150, 255);
        noStroke(); // Garante que os faróis não tenham contorno indesejado
        fill(255, 255, 100, lightBrightness); // Amarelo para faróis
        ellipse(68, 5, 5, 5); // Farol dianteiro

        // Lanternas traseiras
        noStroke(); // Garante que as lanternas não tenham contorno indesejado
        fill(255, 0, 0, 200); // Vermelho para lanterna traseira
        ellipse(2, 5, 5, 5);
    }

    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha estrelas no céu noturno.
 * @param {number} numStars - Número de estrelas a desenhar.
 */
function drawStars(numStars) {
    for (let i = 0; i < numStars; i++) {
        let x = random(width); // Posição X aleatória
        let y = random(height * 0.5); // Posição Y aleatória (apenas na metade superior do céu)
        let starSize = random(1, 3); // Tamanho da estrela aleatório
        let starAlpha = random(100, 255); // Brilho variável

        fill(255, 255, 200, starAlpha); // Amarelo claro com transparência
        noStroke(); // Sem contorno
        ellipse(x, y, starSize, starSize); // Desenha a estrela
    }
}

/**
 * Desenha uma fogueira animada.
 * @param {number} x - Coordenada X da fogueira.
 * @param {number} y - Coordenada Y da fogueira.
 */
function drawCampfire(x, y) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a posição da fogueira

    // Troncos (base)
    fill(100, 50, 0); // Marrom escuro
    rect(-20, 0, 40, 10); // Tronco central
    rotate(PI / 6);        // Gira para desenhar outro tronco
    rect(-20, 0, 40, 10);
    rotate(-PI / 3);       // Gira novamente
    rect(-20, 0, 40, 10);

    // Chamas (animadas)
    noStroke(); // Sem contorno
    // Altura e largura das chamas variam com o tempo para simular animação
    let flameHeight = 30 + sin(frameCount * 0.3) * 10;
    let flameWidth = 20 + cos(frameCount * 0.2) * 5;

    // Cores das chamas (múltiplas camadas para efeito de gradiente)
    fill(255, 200, 0, 200); // Amarelo
    ellipse(0, -flameHeight, flameWidth, flameHeight * 1.5); // Chama maior

    fill(255, 100, 0, 200); // Laranja
    ellipse(0, -flameHeight * 0.7, flameWidth * 0.8, flameHeight * 1.2); // Chama média

    fill(255, 0, 0, 150); // Vermelho
    ellipse(0, -flameHeight * 0.4, flameWidth * 0.6, flameHeight * 0.8); // Chama menor

    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha o efeito de brilho ao redor da fogueira.
 * @param {number} x - Coordenada X da fogueira.
 * @param {number} y - Coordenada Y da fogueira.
 */
function drawCampfireGlow(x, y) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a posição da fogueira
    noStroke(); // Sem contorno
    let glowAlpha = map(sin(frameCount * 0.1), -1, 1, 50, 150); // Brilho pulsante
    fill(255, 150, 0, glowAlpha); // Laranja amarelado com transparência
    ellipse(0, 0, 100, 60); // Elipse para o brilho
    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha partículas de confete.
 * @param {number} centerX - Coordenada X da origem dos confetes.
 * @param {number} centerY - Coordenada Y da origem dos confetes.
 * @param {number} num - Número de partículas de confete.
 */
function drawConfetti(centerX, centerY, num) {
    for (let i = 0; i < num; i++) {
        // Posições X e Y aleatórias com base na origem e um pouco de movimento
        let x = centerX + random(-100, 100) + sin(frameCount * 0.1 + i) * 20;
        let y = centerY + random(-50, 50) + cos(frameCount * 0.08 + i) * 20;
        let size = random(5, 15); // Tamanho aleatório
        let angle = random(TWO_PI); // Ângulo de rotação aleatório
        let confettiColor = color(random(255), random(255), random(255), random(150, 255)); // Cor aleatória com transparência

        push(); // Salva o estado atual da transformação
        translate(x, y); // Move a origem para a posição do confete
        rotate(angle + frameCount * 0.1); // Rotaciona o confete (com animação)
        noStroke(); // Sem contorno
        fill(confettiColor); // Define a cor do confete
        rect(0, 0, size, size); // Desenha o confete como um quadrado
        pop(); // Restaura o estado anterior da transformação
}
}

/**
 * Desenha um celeiro detalhado.
 * @param {number} x - Coordenada X do canto inferior esquerdo da base do celeiro.
 * @param {number} y - Coordenada Y do canto inferior esquerdo da base do celeiro (linha do chão).
 * @param {number} barnWidth - Largura do celeiro.
 * @param {number} barnHeight - Altura do corpo retangular do celeiro.
 */
function drawBarn(x, y, barnWidth = 200, barnHeight = 150) { // Aumentei os valores padrão
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a base do celeiro

    // Fundação de pedra (base do celeiro)
    let foundationHeight = 20; // Aumentado um pouco
    fill(80, 80, 80); // Cinza escuro para a fundação
    noStroke();
    rect(0, -foundationHeight, barnWidth, foundationHeight);

    // Corpo principal do celeiro
    fill(170, 0, 0); // Vermelho clássico de celeiro
    noStroke();
    rect(0, -barnHeight - foundationHeight, barnWidth, barnHeight); // Desenhado acima da fundação

    // Detalhes de textura de madeira no corpo
    stroke(120, 0, 0); // Marrom avermelhado escuro para as linhas
    strokeWeight(1.5); // Aumentei um pouco a espessura para visibilidade no tamanho maior
    // Linhas verticais
    let numVerticalPlanks = 6; // Mais tábuas verticais para o celeiro maior
    for (let i = 1; i < numVerticalPlanks; i++) {
        line(barnWidth / numVerticalPlanks * i, -barnHeight - foundationHeight, barnWidth / numVerticalPlanks * i, -foundationHeight);
    }
    // Linhas horizontais (poucas para não sobrecarregar)
    line(0, -barnHeight * 0.33 - foundationHeight, barnWidth, -barnHeight * 0.33 - foundationHeight);
    line(0, -barnHeight * 0.66 - foundationHeight, barnWidth, -barnHeight * 0.66 - foundationHeight);


    // Telhado
    fill(100, 50, 0); // Marrom para o telhado
    noStroke(); // Remover contorno para o telhado
    let roofPeakY = -barnHeight - foundationHeight - (barnHeight * 0.4); // Telhado um pouco mais alto
    triangle(
        0, -barnHeight - foundationHeight, // Canto inferior esquerdo do telhado
        barnWidth, -barnHeight - foundationHeight, // Canto inferior direito do telhado
        barnWidth / 2, roofPeakY // Ponto do topo do telhado
    );

    // Viga do telhado
    stroke(80, 40, 0); // Marrom mais escuro para a viga
    strokeWeight(3); // Viga mais espessa
    line(0, -barnHeight - foundationHeight + 8, barnWidth, -barnHeight - foundationHeight + 8); // Viga superior

    // Portas do celeiro
    fill(139, 69, 19); // Marrom mais claro para as portas
    noStroke(); // Sem contorno para as portas
    let doorWidth = barnWidth * 0.35; // Um pouco mais estreitas proporcionalmente
    let doorHeight = barnHeight * 0.7;
    let doorY = -barnHeight - foundationHeight + (barnHeight - doorHeight);
    rect(barnWidth * 0.5 - doorWidth / 2, doorY, doorWidth, doorHeight);

    // Detalhes das portas (linhas verticais para textura)
    stroke(80, 40, 0); // Marrom escuro para as linhas
    strokeWeight(2);
    line(barnWidth * 0.5 - doorWidth / 2 + doorWidth / 3, doorY, barnWidth * 0.5 - doorWidth / 2 + doorWidth / 3, doorY + doorHeight);
    line(barnWidth * 0.5 + doorWidth / 2 - doorWidth / 3, doorY, barnWidth * 0.5 + doorWidth / 2 - doorWidth / 3, doorY + doorHeight);
    // Linha horizontal no meio das portas
    line(barnWidth * 0.5 - doorWidth / 2, doorY + doorHeight / 2, barnWidth * 0.5 + doorWidth / 2, doorY + doorHeight / 2);


    // Alças das portas (pequenos círculos)
    noStroke();
    fill(50, 50, 50); // Cinza escuro
    ellipse(barnWidth * 0.5 - doorWidth / 4, doorY + doorHeight * 0.4, 5, 5); // Posição ajustada
    ellipse(barnWidth * 0.5 + doorWidth / 4, doorY + doorHeight * 0.4, 5, 5); // Posição ajustada

    // Janelas pequenas no celeiro
    fill(150, 200, 255); // Azul claro para as janelas
    let windowSize = 20; // Janelas um pouco maiores
    rect(barnWidth * 0.2, -barnHeight - foundationHeight + 30, windowSize, windowSize);
    rect(barnWidth * 0.8 - windowSize, -barnHeight - foundationHeight + 30, windowSize, windowSize);

    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha uma macieira.
 * @param {number} x - Coordenada X do centro da base do tronco da árvore.
 * @param {number} y - Coordenada Y da base do tronco da árvore (linha do chão).
 * @param {number} treeWidth - Largura total da árvore (incluindo copa).
 * @param {number} treeHeight - Altura total da árvore (do chão ao topo da copa).
 */
function drawAppleTree(x, y, treeWidth = 100, treeHeight = 120) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a base da árvore

    let trunkWidth = treeWidth * 0.15; // Largura do tronco
    let trunkHeight = treeHeight * 0.4; // Altura do tronco

    // Tronco (marrom)
    fill(100, 50, 0); // Cor de madeira
    noStroke();
    rect(-trunkWidth / 2, -trunkHeight, trunkWidth, trunkHeight); // Desenhado para cima a partir do Y

    // Copa da árvore (verde)
    fill(60, 179, 113); // Verde médio
    noStroke();
    let canopyY = -trunkHeight; // A copa começa no topo do tronco

    // Múltiplas elipses para a copa
    ellipse(0, canopyY - treeHeight * 0.3, treeWidth * 0.8, treeHeight * 0.6); // Elipse central
    ellipse(-treeWidth * 0.2, canopyY - treeHeight * 0.2, treeWidth * 0.5, treeHeight * 0.4); // Elipse esquerda
    ellipse(treeWidth * 0.2, canopyY - treeHeight * 0.2, treeWidth * 0.5, treeHeight * 0.4); // Elipse direita
    ellipse(0, canopyY - treeHeight * 0.05, treeWidth * 0.6, treeHeight * 0.3); // Elipse na parte inferior da copa (grudada no tronco)

    // Maçãs (pequenos círculos vermelhos)
    fill(255, 0, 0); // Vermelho vibrante
    // Posições fixas para as maçãs (em vez de random a cada frame)
    let appleSize = 8;

    // Maçã 1
    ellipse(-treeWidth * 0.1, canopyY - treeHeight * 0.4, appleSize, appleSize);
    // Maçã 2
    ellipse(treeWidth * 0.15, canopyY - treeHeight * 0.3, appleSize, appleSize);
    // Maçã 3
    ellipse(-treeWidth * 0.25, canopyY - treeHeight * 0.2, appleSize, appleSize);
    // Maçã 4
    ellipse(treeWidth * 0.05, canopyY - treeHeight * 0.1, appleSize, appleSize);
    // Maçã 5
    ellipse(treeWidth * 0.2, canopyY - treeHeight * 0.45, appleSize, appleSize);
    // Maçã 6
    ellipse(-treeWidth * 0.08, canopyY - treeHeight * 0.15, appleSize, appleSize);
    // Maçã 7
    ellipse(treeWidth * 0.28, canopyY - treeHeight * 0.25, appleSize, appleSize);
    // Maçã 8
    ellipse(-treeWidth * 0.15, canopyY - treeHeight * 0.35, appleSize, appleSize);

    pop(); // Restaura o estado anterior da transformação
}

/**
 * Desenha um bloco de feno.
 * @param {number} x - Coordenada X do canto inferior esquerdo do bloco de feno.
 * @param {number} y - Coordenada Y da base do bloco de feno (linha do chão).
 * @param {number} baleWidth - Largura do bloco de feno.
 * @param {number} baleHeight - Altura do bloco de feno.
 */
function drawHayBale(x, y, baleWidth = 60, baleHeight = 40) {
    push(); // Salva o estado atual da transformação
    translate(x, y); // Move a origem para a base do bloco de feno

    // Corpo principal do feno
    fill(220, 180, 50); // Cor de palha/feno (amarelo amarronzado)
    noStroke();
    rect(0, -baleHeight, baleWidth, baleHeight); // Desenhado acima do Y

    // Detalhes da textura do feno (linhas escuras)
    stroke(150, 100, 0); // Marrom mais escuro para os detalhes
    strokeWeight(1);
    // Linhas horizontais
    line(0, -baleHeight * 0.33, baleWidth, -baleHeight * 0.33);
    line(0, -baleHeight * 0.66, baleWidth, -baleHeight * 0.66);
    // Linhas verticais
    line(baleWidth * 0.25, -baleHeight, baleWidth * 0.25, 0);
    line(baleWidth * 0.75, -baleHeight, baleWidth * 0.75, 0);

    pop(); // Restaura o estado anterior da transformação
}